@echo off
title Spellbinder Desktop - Uninstall
del "%USERPROFILE%\Desktop\Spellbinder.lnk" 2>nul
echo Spellbinder shortcut removed from your Desktop.
echo (Nothing else was installed, so there is nothing else to remove.)
pause
