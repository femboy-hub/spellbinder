# Spellbinder Desktop - installer
# Puts a Spellbinder shortcut on your Desktop. The shortcut opens
# spellbinder.jakson.is-a.dev in its own window (no browser bars),
# using Microsoft Edge, or Chrome if Edge is not found.
# Spellbinder needs the real website address for Google sign-in to work,
# so the desktop version opens the live site in app mode - same account,
# same collection, always up to date.

$ErrorActionPreference = 'Stop'
$url = 'https://spellbinder.jakson.is-a.dev'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$icon = Join-Path $folder 'spellbinder.ico'

# Find Edge first (comes with Windows), then Chrome
$candidates = @(
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$browser = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) {
  Write-Host "Could not find Microsoft Edge or Google Chrome on this PC."
  Write-Host "Install one of them, then run this installer again."
  Read-Host "Press Enter to close"
  exit 1
}

$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Spellbinder.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $browser
$shortcut.Arguments = "--app=$url"
$shortcut.WorkingDirectory = Split-Path $browser
$shortcut.Description = 'Spellbinder - your Magic collection'
if (Test-Path $icon) { $shortcut.IconLocation = "$icon,0" }
$shortcut.Save()

Write-Host ""
Write-Host "Done! Spellbinder is now on your Desktop."
Write-Host "Double-click the Spellbinder icon to open it in its own window."
Write-Host ""
Read-Host "Press Enter to close"
