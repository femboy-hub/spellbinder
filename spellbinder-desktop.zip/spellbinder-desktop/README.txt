SPELLBINDER - DESKTOP VERSION (Windows)
========================================

WHAT THIS IS
Spellbinder on your computer desktop, in its own window with no
browser address bar - like a real program. It opens the live
Spellbinder site, so your sign-in, binders, and prices are exactly
the same as on your phone, and it is always the newest version.
(Google sign-in only works from Spellbinder's real web address,
which is why the desktop version works this way.)

HOW TO INSTALL
1. Unzip this folder anywhere (Downloads is fine).
2. Double-click "Install Spellbinder Desktop.bat".
3. A Spellbinder icon appears on your Desktop.
4. Double-click it any time to open Spellbinder.

You need Microsoft Edge or Google Chrome on the PC - Edge comes
with Windows, so you almost certainly already have it.
You also need internet, same as the website.

HOW TO REMOVE IT
Double-click "Uninstall Spellbinder Desktop.bat", or just delete
the Spellbinder icon from your Desktop. Nothing else was installed.

Made for Jakson - November 27, 2026
