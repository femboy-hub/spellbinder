@echo off
title Spellbinder Desktop - Install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-spellbinder.ps1"
